module.exports = {

    FeshionImgData: [
        {
            img: '/assets/images/portfolio/1.jpg'
        },
        {
            img: '/assets/images/portfolio/2.jpg'
        },
        {
            img: '/assets/images/portfolio/3.jpg'
        },
        {
            img: '/assets/images/portfolio/4.jpg'
        }
    ],

    BagsImgData: [
        {
            img: '/assets/images/portfolio/5.jpg'
        },
        {
            img: '/assets/images/portfolio/6.jpg'
        },
        {
            img: '/assets/images/portfolio/7.jpg'
        },
        {
            img: '/assets/images/portfolio/8.png'
        },
    ],

    ShoesImgData: [
        {
            img: '/assets/images/portfolio/9.jpg'
        },
        {
            img: '/assets/images/portfolio/10.jpg'
        },
        {
            img: '/assets/images/portfolio/12.png'
        },
        {
            img: '/assets/images/portfolio/8.png'
        },
    ],

    WatchImgData: [
        {
            img: '/assets/images/portfolio/13.jpg'
        },
        {
            img: '/assets/images/portfolio/11.jpg'
        },
        {
            img: '/assets/images/portfolio/10.jpg'
        },
        {
            img: '/assets/images/portfolio/12.png'
        },
    ],

    AllImgData: [
        {
            img: '/assets/images/portfolio/1.jpg'
        },
        {
            img: '/assets/images/portfolio/2.jpg'
        },
        {
            img: '/assets/images/portfolio/3.jpg'
        },
        {
            img: '/assets/images/portfolio/4.jpg'
        },
        {
            img: '/assets/images/portfolio/5.jpg'
        },
        {
            img: '/assets/images/portfolio/6.jpg'
        },
        {
            img: '/assets/images/portfolio/7.jpg'
        },
        {
            img: '/assets/images/portfolio/8.png'
        },
        {
            img: '/assets/images/portfolio/9.jpg'
        },
        {
            img: '/assets/images/portfolio/10.jpg'
        },
        {
            img: '/assets/images/portfolio/11.jpg'
        },
        {
            img: '/assets/images/portfolio/12.png'
        },
    ],
}
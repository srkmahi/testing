module.exports = {

    BrandData : [
        {
            img:'/assets/images/yoga-img/brand/1.png'
        },
        {
            img:'/assets/images/yoga-img/brand/2.png'
        },
        {
            img:'/assets/images/yoga-img/brand/3.png'
        },
        {
            img:'/assets/images/yoga-img/brand/4.png'
        },
        {
            img:'/assets/images/yoga-img/brand/1.png'
        },
        {
            img:'/assets/images/yoga-img/brand/2.png'
        }
    ],

    BlogData:[
        {
            img:'/assets/images/yoga-img/blog/1.jpg',
            role:'admin',
            date:'5 September 2019',
            text:'Find Great Speaker For Event.',
            heading:'Detais This Event',
            desc:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard .'
        },
        {
            img:'/assets/images/yoga-img/blog/2.jpg',
            role:'admin',
            date:'5 September 2019',
            text:'Find Great Speaker For Event.',
            heading:'Detais This Event',
            desc:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard .'
        },
        {
            img:'/assets/images/yoga-img/blog/3.jpg',
            role:'admin',
            date:'5 September 2019',
            text:'Find Great Speaker For Event.',
            heading:'Detais This Event',
            desc:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard .'
        },
        {
            img:'/assets/images/yoga-img/blog/1.jpg',
            role:'admin',
            date:'5 September 2019',
            text:'Find Great Speaker For Event.',
            heading:'Detais This Event',
            desc:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard .'
        },
    ],

    PricingData:[
        {
            img:'/assets/images/yoga-img/abs-yoga.png',
            heading:'free',
            feature1:'Lorem Ipsum is simply',
            feature2:'dummy text of the',
            feature3:'printing and typesetting',
            price:'0'
        },
        {
            img:'/assets/images/yoga-img/abs-yoga.png',
            heading:'medium',
            feature1:'Lorem Ipsum is simply',
            feature2:'dummy text of the',
            feature3:'printing and typesetting',
            price:'49'
        },
        {
            img:'/assets/images/yoga-img/abs-yoga.png',
            heading:'business',
            feature1:'Lorem Ipsum is simply',
            feature2:'dummy text of the',
            feature3:'printing and typesetting',
            price:'99'
        },
        {
            img:'/assets/images/yoga-img/abs-yoga.png',
            heading:'business',
            feature1:'Lorem Ipsum is simply',
            feature2:'dummy text of the',
            feature3:'printing and typesetting',
            price:'0'
        }
    ],

    ExpertData : [
        {
            img:'/assets/images/yoga-img/expert/1.jpg',
            heading:'Ethan Robbines',
        },
        {
            img:'/assets/images/yoga-img/expert/2.jpg',
            heading:'Ethan Robbines',
        },
        {
            img:'/assets/images/yoga-img/expert/3.jpg',
            heading:'Ethan Robbines',
        },
        {
            img:'/assets/images/yoga-img/expert/4.jpg',
            heading:'Ethan Robbines',
        },
        {
            img:'/assets/images/yoga-img/expert/5.jpg',
            heading:'Ethan Robbines',
        },
        {
            img:'/assets/images/yoga-img/expert/1.jpg',
            heading:'Ethan Robbines',
        },
        {
            img:'/assets/images/yoga-img/expert/2.jpg',
            heading:'Ethan Robbines',
        },
        {
            img:'/assets/images/yoga-img/expert/3.jpg',
            heading:'Ethan Robbines',
        },
        {
            img:'/assets/images/yoga-img/expert/3.jpg',
            heading:'Ethan Robbines',
        },
        {
            img:'/assets/images/yoga-img/expert/3.jpg',
            heading:'Ethan Robbines',
        },
    ]

}
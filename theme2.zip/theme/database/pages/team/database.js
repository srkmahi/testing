module.exports = {
    AgencyData:[
        { 
            img:'/assets/images/event/l3-1.png',
            name:'Sam Rowling',
            role:'Team Leader - otstrab',
            desc:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'
        },
        { 
            img:'/assets/images/event/l3-3.png',
            name:'Mark Tucker',
            role:'App Developer - Jumpster',
            desc:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'
        },
        { 
            img:'/assets/images/event/l3-4.png',
            name:'Sam Rowling',
            role:'Team Leader - otstrab',
            desc:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'
        },
        { 
            img:'/assets/images/event/l3-1.png',
            name:'Sam Rowling',
            role:'Team Leader - otstrab',
            desc:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'
        },
        { 
            img:'/assets/images/event/l3-2.png',
            name:'Sam Rowling',
            role:'Team Leader - otstrab',
            desc:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'
        },
        { 
            img:'/assets/images/event/l3-3.png',
            name:'Mark Tucker',
            role:'App Developer - Jumpster',
            desc:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'
        },
        { 
            img:'/assets/images/event/l3-4.png',
            name:'Sam Rowling',
            role:'Team Leader - otstrab',
            desc:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'
        },
        { 
            img:'/assets/images/event/l3-1.png',
            name:'Sam Rowling',
            role:'Team Leader - otstrab',
            desc:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'
        },
        { 
            img:'/assets/images/event/l3-2.png',
            name:'Sam Rowling',
            role:'Team Leader - otstrab',
            desc:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'
        },
        { 
            img:'/assets/images/event/l3-3.png',
            name:'Mark Tucker',
            role:'App Developer - Jumpster',
            desc:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'
        },
        { 
            img:'/assets/images/event/l3-4.png',
            name:'Sam Rowling',
            role:'Team Leader - otstrab',
            desc:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'
        },
        { 
            img:'/assets/images/event/l3-1.png',
            name:'Sam Rowling',
            role:'Team Leader - otstrab',
            desc:'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry`s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'
        },
    ],

    AppData:[
        {
            img:'../assets/images/app_landing2/team/1.png',
            name:'ken pitersan',
            role:'Seniour UI/Xi Designer'
        },
        {
            img:'../assets/images/app_landing2/team/2.png',
            name:'ken pitersan',
            role:'Seniour UI/Xi Designer'
        },
        {
            img:'../assets/images/app_landing2/team/3.png',
            name:'ken pitersan',
            role:'Seniour UI/Xi Designer'
        },
        {
            img:'../assets/images/app_landing2/team/4.png',
            name:'ken pitersan',
            role:'Seniour UI/Xi Designer'
        },
    ],
   
}
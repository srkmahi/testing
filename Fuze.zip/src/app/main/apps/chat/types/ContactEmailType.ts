/**
 * Contact Email Type
 */
export type ContactEmailType = { email: string; label: string };

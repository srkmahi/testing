/**
 * Contact Phone Number Type
 */
export type ContactPhoneNumberType = { country: string; phoneNumber: string; label: string };

/**
 * Product Image Type
 */
export type ProductImageType = {
	id: string;
	url: string;
	type: string;
};

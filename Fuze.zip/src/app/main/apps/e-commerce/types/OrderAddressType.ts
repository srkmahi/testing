/**
 * Order Address Type
 */
export type OrderAddressType = {
	address: string;
	lat: number;
	lng: number;
};

/**
 * Order Status Type
 */
export type OrderStatusType = {
	id: string;
	name: string;
	color: string;
	date?: string;
};

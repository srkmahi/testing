/**
 * Tag Type
 */
export type TagType = {
	id: string;
	title: string;
};

export type TagsType = TagType[];

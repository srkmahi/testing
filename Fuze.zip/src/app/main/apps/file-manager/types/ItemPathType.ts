/**
 * Item Path Type
 */
export type ItemPathType = { id: string; name: string }[];

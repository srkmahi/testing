/**
 * Label Type
 */
export type LabelType = {
	id: string;
	boardId: string;
	title: string;
};

/**
 * Labels Type
 */
export type LabelsType = LabelType[];

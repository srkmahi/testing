/**
 * Route params type
 */
type RouteParamsType = {
	folderHandle?: string;
	labelHandle?: string;
	filterHandle?: string;
	mailId?: string;
};

export default RouteParamsType;

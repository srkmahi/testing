/**
 * Media Type
 */
export type MediaType = {
	type: string;
	title: string;
	preview: string;
};

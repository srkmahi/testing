/**
 * User Type
 */
export type UserType = {
	name: string;
	avatar: string;
};

import { FuseNavItemType } from './FuseNavItemType';

export type FuseNavigationType = FuseNavItemType[];

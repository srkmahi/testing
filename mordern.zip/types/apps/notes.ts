export interface NotesType {
  id: number;
  color?: string;
  title?: string;
  datef?: any | string;
  deleted: boolean;
}
